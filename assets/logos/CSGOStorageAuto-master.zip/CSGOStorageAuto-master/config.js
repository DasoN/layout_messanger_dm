module.exports = {
    accountName: "username",
    password: "password",
    steam_id: "steam_id",
    file_path: "items.txt"
}
