# csgo-supply-unit-automation
Repository for automatically updating storage units in csgo
